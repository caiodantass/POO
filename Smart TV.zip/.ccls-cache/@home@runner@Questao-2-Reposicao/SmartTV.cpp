#include <iostream>
#include <string>
#include "Aplicativo.h"
#include "SmartTV.h"
using namespace std;

std::ostream& operator<<(std::ostream& os, const SmartTV& smart){
    for(int i = 0; i < smart.quantidadeDeAplicativos; i++){
        os << smart.listaDeAplicativos[i] << endl;
    }
    return os;
}

SmartTV::SmartTV() {
    this->quantidadeDeAplicativos = 0;
}

SmartTV::SmartTV(int quantidadeDeAplicativos) {
    setQuantidadeDeAplicativos(quantidadeDeAplicativos);
}


void SmartTV::operator<<(const Aplicativo& aplicativo){
    listaDeAplicativos[quantidadeDeAplicativos] = aplicativo;
    quantidadeDeAplicativos++;
}


void SmartTV::operator>>(const Aplicativo& aplicativo){
    for(int i = 0; i < quantidadeDeAplicativos; i++){
        if(listaDeAplicativos[i].getNome() == aplicativo.getNome()){
            for(int j = i; j < quantidadeDeAplicativos; j++){
                listaDeAplicativos[j] = listaDeAplicativos[j+1];
            }
            quantidadeDeAplicativos--;
        }
    }
}