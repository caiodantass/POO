#include <iostream>
#include <string>
#include "Aplicativo.h"
using namespace std;

std::ostream& operator<<(std::ostream& os, const Aplicativo& aplicativo){
    os << "Nome: " << aplicativo.nome << endl;
    os << "Categoria: " << aplicativo.categoria << endl;
    os << "Data da última atualização: " << aplicativo.data << endl;
    return os;
}

Aplicativo::Aplicativo() {
    this->nome = "valor default";
    this->categoria = "vazio";
    this->data = "valor default";
}

Aplicativo::Aplicativo(string nome, string categoria, string data){
    setNome(nome);
    setCategoria(categoria);
    setData(data);
}
