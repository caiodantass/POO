#ifndef SMART_TV_H
#define SMART_TV_H

#include <string>
#include "Aplicativo.h"
#include <iostream>
using namespace std;

class SmartTV {

friend std::ostream& operator<<(std::ostream& os, const SmartTV& smart);

public:
    SmartTV();
    SmartTV(int quantidadeDeAplicativos);

    void setQuantidadeDeAplicativos(int quantidadeDeAplicativos){this->quantidadeDeAplicativos = quantidadeDeAplicativos;}
    int getQuantidadeDeAplicativos()const{return quantidadeDeAplicativos;}

    void operator<<(const Aplicativo& aplicativo); 
    void operator>>(const Aplicativo& aplicativo); 

private:
    Aplicativo listaDeAplicativos[40];
    int quantidadeDeAplicativos;
};

#endif