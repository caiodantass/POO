#ifndef APLICATIVO_H
#define APLICATIVO_H

#include <string>
#include <iostream>
using namespace std;

class Aplicativo{

friend std::ostream& operator<<(std::ostream& os, const Aplicativo& aplicativo);

public:
    Aplicativo();
    Aplicativo(string nome, string categoria, string data);

    void setNome(string nome){this -> nome = nome;}
    void setCategoria(string categoria){this -> categoria = categoria;}
    void setData(string data){this -> data = data;}

    string getNome()const{return nome;}
    string getCategoria()const{return categoria;}
    string getData()const{return data;}

protected:
    string nome;
    string categoria;
    string data;

};

#endif