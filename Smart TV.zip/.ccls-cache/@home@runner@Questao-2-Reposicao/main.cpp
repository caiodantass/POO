#include <iostream>
#include <string>
#include "Aplicativo.h"
#include "SmartTV.h"
using namespace std;

int main(){

    Aplicativo a1("Netflix", "Filme", "01/01/2022");
    Aplicativo a2("Amazon", "Filme", "01/01/2020");
    Aplicativo a3("Instagram", "Entretedimento", "01/01/2022");
    Aplicativo a4("Google", "Pesquisa", "01/01/2022");
    Aplicativo a5("Googleplay", "Filme", "01/01/2020");
    Aplicativo a6("WhatsApp", "Conversa", "01/01/2021");
    Aplicativo a7("Facebook", "Conversa", "01/01/2020");
    

    SmartTV t1;
    //instalando os aplicativos na smart tv
    cout << "Instalando aplicativos na Smart TV!" << endl;
    t1 << a1;
    t1 << a2;
    t1 << a3;
    t1 << a4;
    t1 << a5;
    t1 << a6;
    t1 << a7;
    cout << "Aplicativos instalados na Smart TV: " << t1.getQuantidadeDeAplicativos() << endl;

    cout <<endl<< t1 << endl;
    
    //desinstalando os aplicativos na smart tv
    cout << "Desinstalando aplicativos na Smart TV!";
    t1 >> a1;
    t1 >> a2;
    t1 >> a3;
    t1 >> a4;

    cout << endl;
    cout << "Aplicativos desinstalados da Smart TV, Quantidades restantes: " << t1.getQuantidadeDeAplicativos() << endl << endl;
    cout << t1 << endl;
}